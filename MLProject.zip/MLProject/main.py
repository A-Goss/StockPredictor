import pandas as pd
import numpy as np
from scipy.stats import f
from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn2 import *
from matplotlib import pyplot as plt
from alpha_vantage.timeseries import TimeSeries
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from dotenv import load_dotenv
import os
import seaborn as sns
from sklearn.ensemble import RandomForestRegressor
from datetime import datetime, timedelta
from sklearn.decomposition import PCA

# Load environment variables
load_dotenv()

# return the predicted value from Random Forest
def rf(x_train, y_train, x_test):
    random_forest_model = RandomForestRegressor(n_estimators=200)
    random_forest_model.fit(x_train, y_train)
    pred = random_forest_model.predict(x_test)
    return pred

# function to iterate through the test dataset and predict the next day's close value using Random Forest
def iterate(x_train, y_train, x_test, y_test, tomorrow, date):
    x_history = [i for i in x_train]
    y_history = [i for i in y_train]
    preds = []
    for i in range(len(x_test)):
        pred = rf(x_history, y_history, x_test[i].reshape(1, -1))  # send x_test row by row to make a prediction
        preds.append(pred)

        print(f'Date: {date[i]}\t Expected: {y_test[i]:.3f}\t Predicted: {pred}')
        x_history.append(x_test[i])
        y_history.append(y_test[i])

    error = mean_absolute_error(y_test, preds)
    print(f'Mean absolute error: {error}')
    print(f'Tomorrow closing value: {rf(x_history, y_history, tomorrow.reshape(1, -1))}\n')
    return preds

# graph the dataset and the predicted values of each algorithm
def graph(preds, y_test, x_train, date_set, x_test, pred):
    plt.figure(figsize=(14, 7))
    plt.plot(date_set[len(date_set)//2:], y_test[len(date_set)//2:], c='red', label='Actual')
    plt.plot(date_set[len(date_set)//2:], preds[len(date_set)//2:], c='blue', label='Predicted')
    plt.plot(date_set[len(date_set)//2:], pred[len(date_set)//2:], 'y--', label='MLR Predictions')
    plt.plot(date_set[len(date_set)//2:len(x_train)], y_test[len(date_set)//2:len(x_train)], 'green',label='Training Data')
    plt.xticks(date_set[len(date_set)//2::3], rotation=45)
    plt.xlabel("Time")
    plt.ylabel("Close Prices")
    plt.title("Predicted vs. Actual Close Prices")
    plt.legend(loc='lower left')
    plt.show()
'''
#CHATGPT STUFF IGNORE FOR NOW
def graph(preds, y_all, dates_all, test_size, pred_mlr):
    plt.figure(figsize=(14, 7))

    # Split indices for training and testing
    train_end = len(y_all) - test_size
    test_dates = dates_all[train_end:]
    train_dates = dates_all[:train_end]

    # Plot actual values (Training and Test data)
    plt.plot(train_dates, y_all[:train_end], label='Training Data', color='green')
    plt.plot(test_dates, y_all[train_end:], label='Actual (Test)', color='red')

    # Plot predictions (RF and MLR)
    plt.plot(test_dates, preds[train_end:], label='RF Predicted', color='blue')
    plt.plot(test_dates, pred_mlr[train_end:], '--', label='MLR Predictions', color='orange')

    # Ensure x-ticks cover the entire range (train + test), including predictions
    all_dates = dates_all  # This includes both training and test dates
    plt.xticks(all_dates[::3], rotation=45)  # Every third date for readability

    plt.xlabel("Date")
    plt.ylabel("Close Prices")
    plt.title("Predicted vs. Actual Close Prices")
    plt.legend()
    plt.tight_layout()
    plt.show()
'''

def next_dates():
    date = pd.to_datetime(np.array(df['date'][::-1]))

    for i in range(1, 11):
        current_date = date[-1]
        incremented_date = current_date + timedelta(days=i)
        date = pd.to_datetime(np.append(date, incremented_date))
    return date
 
def plot_data():
    newx = np.array(df['date'][::-1])
    scatter_x = newx[::-10][::-1]
    scatter_y = y[::-10][::-1]
    print(scatter_x)

    plt.figure(figsize=(14,7))
    plt.plot(newx, y)
    plt.scatter(scatter_x, scatter_y, marker='*', color='r')
    for i in range(len(scatter_x)):
        plt.text(scatter_x[i], scatter_y[i], scatter_y[i], fontsize=9, ha='right', va='bottom')
    plt.title('Closing values')
    plt.xlabel('Date')
    plt.ylabel('Closing Value')
    plt.xticks(scatter_x)
    plt.show()
 
# read the dataset
df = pd.read_csv('daily_markets/AAPL/AAPL_daily_market.csv')

x = np.array(df.drop(columns=['date'], axis=1)[::-1])  # reverse
#y = np.array(df['4. close'][::-1].shift(-1))  # reverse
y = df['4. close'][::-1].shift(-1).to_numpy()
tomorrow = x[-1]
dates = np.array(df['date'][::-1])

date_set = next_dates()


# remove the last row from the dataset
x = x[:-1]
y = y[:-1]
dates = dates[:-1]  # Ensure date length matches


# x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.15, random_state=1)
split_size = 15  # Last 15 days for testing
x_train, x_test = x[:-split_size], x[-split_size:]
y_train, y_test = y[:-split_size], y[-split_size:]
dates_train, dates_test = dates[:-split_size], dates[-split_size:]



# rf
print("Predicting the next day's close value using Random Forest...")
predictions = iterate(x_train, y_train, x_test, y_test, tomorrow, dates_test)

# mlr with pca
pca = PCA(n_components=2)
x_trainPCA = pca.fit_transform(x_train)
x_testPCA = pca.transform(x_test)

print("Predicting the next day's close value using Multiple Linear Regression(with PCA)...")
model = LinearRegression()
reg = model.fit(x_trainPCA, y_train)
predMLR = reg.predict(x_testPCA)

for i in range(len(predMLR)):
    print(f'Expected: {y_test[i]:.3f}\t Predicted: {predMLR[i]:.3f}\t Difference: {y_test[i] - predMLR[i]:.3f}')


y_test = np.append(y_train, y_test)
preds = np.append(y_train, predictions)
predMLR = np.append(y_train, predMLR)
dates_full = np.append(dates_train, dates_test)
graph(preds, y_test, x_train, dates_full, x_test, predMLR)
#CHATGPT STUFF
#graph(preds, y_test, dates_full, split_size, predMLR)
#graph(preds, y_test, x_train, date_set[:-2], x_test, predMLR)