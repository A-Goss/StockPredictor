import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error, mean_absolute_error,r2_score
from matplotlib import pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import seaborn as sns
from sklearn.ensemble import RandomForestRegressor
from sklearn.decomposition import PCA
import yfinance as yf
import os

# return the predicted value from Random Forest 
def rf(x_train, y_train, x_test):
    random_forest_model = RandomForestRegressor(n_estimators=100)
    random_forest_model.fit(x_train, y_train)
    pred = random_forest_model.predict(x_test)
    return pred

# function to iterate through the test dataset so we can predict the next day's close value using Random Forest
def iterate(x_train, y_train, x_test, y_test, tomorrow):
    x_history = [i for i in x_train]
    y_history = [i for i in y_train]
    preds = []
    
    for i in range(len(x_test)): 
        pred = rf(x_history, y_history, x_test[i].reshape(1, -1))  # send x_test row by row to make a prediction
        preds.append(pred)

        print(f'Expected: {y_test[i]:.3f}\t Predicted: {pred}')
        x_history.append(x_test[i])
        y_history.append(y_test[i])

    #using all the training/testing we use the latest row of data/latest day to predict the next day closing value
    print(f'Tomorrow closing value: {rf(x_history, y_history, tomorrow.reshape(1, -1))}\n')
    return preds

# shows why PCA is needed due to all but volume correlating
def correlation():
    corr_matrix = df.drop(['Date'], axis=1).corr()

    sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', vmin=-1, vmax=1)
    plt.title('Heatmap for Correlation')
    plt.show()

# graph the dataset and the predicted values of each algorithm
def graph(dates, actual, pred_RF, pred_MLR, pred_PCA):
    plt.figure(figsize=(14, 7))

    plt.plot(dates, actual, c='red', label='Testing')
    plt.plot(dates, pred_RF, c='blue', label='RF Predicted')
    plt.plot(dates, pred_MLR, 'y--', label='MLR Predicted')
    plt.plot(dates, pred_PCA, 'm--', label='PCA Predicted')
    plt.plot(dates[:-15], actual[:-15], 'green', label='Training')

    plt.xticks(dates[::7], rotation=45)
    plt.xlabel("Time")
    plt.ylabel("Close Prices")
    plt.title("Predicted vs. Actual Close Prices")
    plt.legend(loc='lower left')
    plt.show()

def mlr(x_train, y_train, x_test):
    model = LinearRegression()
    reg = model.fit(x_train, y_train)
    pred_MLR = reg.predict(x_test)

    for i in range(len(pred_MLR)):
        print(f'Expected: {y_test[i]:.3f}\t Predicted: {pred_MLR[i]:.3f}\t Difference: {y_test[i] - pred_MLR[i]:.3f}')

    return pred_MLR

def pca(x_train, x_test):
    pca_model = PCA(n_components=2)

    x_train_PCA = pca_model.fit_transform(x_train)
    x_test_PCA = pca_model.transform(x_test)

    return x_train_PCA, x_test_PCA


def correct_directional(test, pred):
    correct = 0
    for i in range(len(test) - 1):
        if test[i] - test[i+1] > 0 and pred[i] - pred[i+1] > 0:
            correct += 1
        elif test[i] - test[i+1] < 0 and pred[i] - pred[i+1] < 0:
            correct += 1
    
    return correct / (len(test)-1)

# Compares the rf, mlr, pca for manual and built-in splitting
def mse_mae(x_train, x_test, y_train, y_test):
    # rf
    print("Predicting the next day's close value using Random Forest...")
    pred_RF = iterate(x_train, y_train, x_test, y_test, tomorrow)

    # mlr
    print("Predicting the next day's close value using Multiple Linear Regression...")
    pred_MLR = mlr(x_train, y_train, x_test)

    # pca-mlr
    print("\nPredicting the next day's close value using PCA and Multiple Linear Regression...")
    x_train_PCA, x_test_PCA = pca(x_train[:, 1:5], x_test[:, 1:5])
    pred_PCA = mlr(x_train_PCA, y_train, x_test_PCA)

    print("\nRandom Forest Mean Squared Error:", mean_squared_error(y_test, pred_RF))
    print("MLR Mean Squared Error:", mean_squared_error(y_test, pred_MLR))
    print("PCA-MLR Mean Squared Error:", mean_squared_error(y_test, pred_PCA))
    

    print("\nRandom Forest Mean Absolute Error:", mean_absolute_error(y_test, pred_RF))
    print("MLR Mean Absolute Error:", mean_absolute_error(y_test, pred_MLR))
    print("PCA-MLR Mean Absolute Error:", mean_absolute_error(y_test, pred_PCA))

    print('\nProportional correctly guessing market gain or drop')
    print(f'Random Forest: {correct_directional(y_test, pred_RF)}')
    print(f'MLR: {correct_directional(y_test, pred_MLR)}')
    print(f'PCA-MLR: {correct_directional(y_test, pred_PCA)}')
    
    print("\nR2 score/ accuracy of our variance of RF: ",r2_score(y_test,pred_RF))
    print("R2 score/ accuracy of our variance of MLR: ",r2_score(y_test,pred_MLR))
    print("R2 score/ accuracy of our variance of PCA-MLR: ",r2_score(y_test,pred_PCA))
    
    # makes equal length graphs
    y_full = np.append(y_train, y_test)
    pred_RF = np.append(y_train, pred_RF)
    pred_MLR = np.append(y_train, pred_MLR)
    pred_PCA = np.append(y_train, pred_PCA)
    graph(date_set[len(date_set)//2:], y_full[len(date_set)//2:], pred_RF[len(date_set)//2:], pred_MLR[len(date_set)//2:], pred_PCA[len(date_set)//2:])

# created data set using API looking at APPLE stocks which broke
#so we have up to March 27
df = pd.read_csv('daily_markets/AAPL/AAPL_newData.csv')

#since we use the close value as a feature to find the next day's closing value
#we shifted the closing value down a row so we can use the day before to help predict the current day
x = np.array(df.drop(columns=['Date'], axis=1)[::-1])  # reverse
y = np.array(df['Close'][::-1].shift(-1))  # reverse
tomorrow = x[-1]#have the most current day(March 27)'s row with features to prediuct the next day March 28'th

date_set = pd.to_datetime(df['Date'][::-1])[:-1]
#it converts the date's in the csv to usable dates in our code and 
#then reveresed so we can have a timeline for the plot

# remove the last row from the dataset b/c we shifted down a row
x = x[:-1]
y = y[:-1]

x_train, x_test, y_train, y_test = train_test_split(x, y, random_state=1, test_size=.15)

# manual splitting so only the last 15 are tested for simulating timeline/realtime apporach
x_train = x[:-15]
x_test = x[-15:]
y_train = y[:-15]
y_test = y[-15:]

#correlation()

#built in split approach/random dates tested 
#x_train, x_test, y_train, y_test = train_test_split(x, y, random_state=1, test_size=.15)

mse_mae(x_train, x_test, y_train, y_test)

'''
#CODE TO GET CSV FILE FOR STOCKS
# Define the ticker symbol
ticker = 'AAPL'

# Download historical data
data = yf.download(ticker, start='2008-01-01', end='2025-06-26')

# Reset index so 'Date' becomes a column
data.reset_index(inplace=True)

# Reorder columns to keep only what's needed
data = data[['Date', 'Open', 'High', 'Low', 'Close', 'Volume']]

# Sort so latest date is first (descending)
data.sort_values('Date', ascending=False, inplace=True)

# Save to CSV
output_dir = 'daily_markets/AAPL'
os.makedirs(output_dir, exist_ok=True)
file_path = f'{output_dir}/AAPL_newData.csv'
data.to_csv(file_path, index=False)

# Preview
print(data.head())
print(f"Data has been saved to '{file_path}'")'''
